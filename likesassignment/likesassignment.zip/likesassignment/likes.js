  toplikesSpan = document.getElementById("topLikes");
  
  function updateLikes(id) {
  toplikesSpan.innerText++;
  }

  midlikesSpan = document.getElementById("midLikes");

  function likesUpdate (id) {
  midlikesSpan.innerText++;
  }

  botlikesSpan = document.getElementById("botLikes");

  function botLikesUpdate (id) {
  botlikesSpan.innerText++;
  }

